#!/usr/bin/env python3
'''
此文件是用来分析仿真数据的源代码，包括：作图、计算吞吐量均值、计算公平指标F
'''
import matplotlib.pyplot as plt
import numpy as np

# 导入数据
cwnd11 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt/graphCwnd_10.1.1.1.txt')
cwnd12 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt/graphCwnd_10.1.2.1.txt')
cwnd21 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt_2/graphCwnd_10.1.1.1.txt')
cwnd22 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt_2/graphCwnd_10.1.2.1.txt')
throput11 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt/graphThroughput_10.1.1.1.txt')
throput12 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt/graphThroughput_10.1.2.1.txt')
throput21 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt_2/graphThroughput_10.1.1.1.txt')
throput22 = np.loadtxt('/Users/szhe/Documents/综合课程设计/tt_2/graphThroughput_10.1.2.1.txt')

# 绘制cwnd图像
plt.figure()
# case1
plt.subplot(121)
plt.xlabel('Time(ns)', fontsize=15)
plt.ylabel('Cwnd(Bytes)', fontsize=15)
# 填充补齐数组
row = cwnd11.shape[0] - cwnd12.shape[0]
cwnd12 = np.pad(cwnd12, ((row, 0), (0,0)), 'constant')
plt.title('Case1', fontsize=17)
plt.grid('true')
plt.plot(cwnd11[:,0],cwnd11[:,1], 'b', cwnd12[:,0], cwnd12[:,1], 'r')
plt.legend(['TCP1', 'TCP2'])
# case2
plt.subplot(122)
plt.xlabel('Time(ns)', fontsize=15)
plt.ylabel('Cwnd(Bytes)', fontsize=15)
plt.title('Case2', fontsize=17)
row = cwnd21.shape[0] - cwnd22.shape[0]
cwnd22 = np.pad(cwnd22, ((row, 0), (0,0)), 'constant')
plt.plot(cwnd21[:,0],cwnd21[:,1], 'b', cwnd22[:,0], cwnd22[:,1], 'r')
plt.suptitle('Cwnd Trendency', fontsize=17)
plt.legend(['TCP1', 'TCP2'])
plt.grid('true')
figname = "cwnd"
plt.savefig(figname)
plt.show()
plt.close()

# 绘制throughput图像
plt.figure()
# case1
plt.subplot(121)
plt.xlabel('Time(ns)', fontsize=15)
plt.ylabel('Throughput(bps)', fontsize=15)
plt.title('Case1', fontsize=15)
plt.grid('true')
plt.plot(throput11[:,0],throput11[:,1], 'b', throput12[:,0], throput12[:,1], 'r')
plt.legend(['TCP1', 'TCP2'])
# case2
plt.subplot(122)
plt.xlabel('Time(ns)', fontsize=15)
plt.ylabel('Throughput(bps)', fontsize=15)
plt.title('Case2', fontsize=15)
plt.plot(throput21[:,0],throput21[:,1], 'b', throput22[:,0], throput22[:,1], 'r')
plt.suptitle('Throughput Trendency', fontsize=17)
plt.legend(['TCP1', 'TCP2'])
plt.grid('true')
figname = "throput"
plt.savefig(figname)
plt.show()
plt.close()

# 计算30-80s内的吞吐量均值
a = np.arange(4, dtype = np.float64)
# case1
# tcp1
a[0] = (np.mean(throput11[30:80], axis=0))[1]
# tcp2
a[1] = (np.mean(throput12[30:80], axis=0))[1]
#case2
# tcp1
a[2] = (np.mean(throput21[30:80], axis=0))[1]
# tcp2
a[3] = (np.mean(throput22[30:80], axis=0))[1]

# 计算公平性F
fairness = np.arange(2, dtype = np.float64)
l = [0, 2]
for i in l:
    if i == 2:
        id = i - 1
    else:
        id = i
    fairness[id] = np.square(a[i]+a[i+1]) / (2 * (np.square(a[i]) + np.square(a[i+1])))

print(a)
print(fairness)
